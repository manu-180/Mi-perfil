LINKEDIN_URL = "https://www.linkedin.com/in/manuel-navarro-b256b52b4/"
IG_URL = "https://www.instagram.com/_manunv/"
MERCADO_PAGO = "https://biolibre.ar/backend"

