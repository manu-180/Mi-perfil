from enum import Enum

class Font(Enum):
    DEFAULT="Poppins"
    TITLE="Poppins"
    LOGO="Confortaa"
    
class FontWeight(Enum):
    LIGTH="300"
    MEDIUM="500"