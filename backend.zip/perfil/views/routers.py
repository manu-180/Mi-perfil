from enum import Enum

class Route(Enum):
    Index = "/"
    Courses = "/cursos"
    CV = "/curriculum&vitae"